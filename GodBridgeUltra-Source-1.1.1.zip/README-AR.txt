GodBridgeUltra 1.1.1 — مصدر Forge 1.8.9

المتطلبات:
- JDK 8
- ForgeGradle 2.1 وMinecraft Forge 1.8.9
- اتصال إنترنت عند أول بناء لتنزيل التبعيات

البناء:
1) فك ضغط الأرشيف.
2) افتح مجلد المشروع في بيئة Gradle متوافقة مع ForgeGradle 2.1.
3) نفّذ: gradlew build
4) ستجد ملف JAR الناتج داخل build/libs.

ملاحظة: لم يتم الادعاء بأن المشروع اجتاز بناءً فعليًا أو اختبارًا داخل PojavLauncher في هذه البيئة.
