package com.godbridge.ultra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class GodBridgeHud {
    private final Minecraft mc = Minecraft.getMinecraft();
    private final GodBridgeUltra mod;

    public GodBridgeHud(GodBridgeUltra mod) {
        this.mod = mod;
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event == null || event.type != RenderGameOverlayEvent.ElementType.TEXT
                || !ModConfig.showHud || mc == null || mc.fontRendererObj == null) return;

        FontRenderer fr = mc.fontRendererObj;
        int x = 5;
        int y = 5;
        String status = "GodBridge: " + (ModConfig.enabled ? "\u00A7aACTIVE" : "\u00A7cDISABLED");
        fr.drawStringWithShadow(status, x, y, 0xFFFFFF);

        if (ModConfig.enabled) {
            String state = "State: \u00A7e" + (mod == null ? "IDLE" : mod.getCurrentState().name());
            fr.drawStringWithShadow(state, x, y + 10, 0xFFFFFF);
            int count = countBlocks();
            fr.drawStringWithShadow("Blocks: " + (count > 0 ? "\u00A7b" + count : "\u00A7cNONE"),
                    x, y + 20, 0xFFFFFF);
            fr.drawStringWithShadow("Mode: \u00A7f" + (ModConfig.staircaseMode ? "Staircase/Jump" : "Flat"),
                    x, y + 30, 0xFFFFFF);
        }
    }

    private int countBlocks() {
        if (mc == null || mc.thePlayer == null || mc.thePlayer.inventory == null) return 0;
        int count = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.thePlayer.inventory.getStackInSlot(i);
            if (stack != null && stack.getItem() instanceof ItemBlock && stack.stackSize > 0) {
                count += stack.stackSize;
            }
        }
        return count;
    }
}
