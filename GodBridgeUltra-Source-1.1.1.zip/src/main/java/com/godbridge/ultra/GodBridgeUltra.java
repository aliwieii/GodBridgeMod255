package com.godbridge.ultra;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.lang.reflect.Field;

@Mod(modid = GodBridgeUltra.MODID, name = GodBridgeUltra.NAME,
        version = GodBridgeUltra.VERSION, clientSideOnly = true)
public class GodBridgeUltra {
    public static final String MODID = "godbridgeultra";
    public static final String NAME = "GodBridgeUltra";
    public static final String VERSION = "1.1.1";

    private final Minecraft mc = Minecraft.getMinecraft();
    private Field rightClickDelayField;
    private KeyBinding toggleKey;
    private KeyBinding configKey;

    public enum BuildState { IDLE, TARGETING, PLACING, WAITING_NEXT_TICK }

    private BuildState currentState = BuildState.IDLE;
    private BlockPos targetPos;
    private EnumFacing targetFacing;
    private Vec3 hitVector;

    private static final EnumFacing[] HORIZONTAL_SEARCH = {
            EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.WEST, EnumFacing.EAST
    };

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        toggleKey = new KeyBinding("key.godbridge.toggle", Keyboard.KEY_B, "key.categories.godbridge");
        configKey = new KeyBinding("key.godbridge.config", Keyboard.KEY_U, "key.categories.godbridge");
        ClientRegistry.registerKeyBinding(toggleKey);
        ClientRegistry.registerKeyBinding(configKey);

        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new GodBridgeHud(this));
        setupReflection();
        ModConfig.loadConfig();
    }

    private void setupReflection() {
        rightClickDelayField = null;
        // 1.8.9 SRG name first, then MCP name. Reflection failure must never stop startup.
        String[] names = {"field_71467_ac", "rightClickDelayTimer"};
        for (String name : names) {
            try {
                Field field = Minecraft.class.getDeclaredField(name);
                field.setAccessible(true);
                rightClickDelayField = field;
                return;
            } catch (NoSuchFieldException ignored) {
                // Try the next known mapping.
            } catch (SecurityException ignored) {
                // Reflection is optional; normal Minecraft behavior remains available.
                return;
            } catch (RuntimeException ignored) {
                // Includes runtime failures from setAccessible on unusual launchers.
                return;
            }
        }
    }

    private void resetRightClickDelay() {
        if (mc == null || rightClickDelayField == null) return;
        try {
            rightClickDelayField.setInt(mc, 0);
        } catch (IllegalAccessException ignored) {
            rightClickDelayField = null;
        } catch (IllegalArgumentException ignored) {
            rightClickDelayField = null;
        } catch (RuntimeException ignored) {
            rightClickDelayField = null;
        }
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (mc == null) return;
        if (toggleKey != null && toggleKey.isPressed()) {
            ModConfig.enabled = !ModConfig.enabled;
            ModConfig.saveConfig();
            if (!ModConfig.enabled) clearTarget();
        }
        if (configKey != null && configKey.isPressed()) {
            mc.displayGuiScreen(new GodBridgeGui());
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START || mc == null) return;
        if (mc.thePlayer == null || mc.theWorld == null || mc.playerController == null) {
            clearTarget();
            return;
        }
        if (!ModConfig.enabled) {
            clearTarget();
            return;
        }
        if (!prepareBlockSlot()) {
            clearTarget();
            return;
        }

        evaluateBuildingTarget();
        if (currentState == BuildState.PLACING && targetPos != null
                && targetFacing != null && hitVector != null) {
            executePlacement();
        }
    }

    private void clearTarget() {
        currentState = BuildState.IDLE;
        targetPos = null;
        targetFacing = null;
        hitVector = null;
    }

    private boolean prepareBlockSlot() {
        if (mc.thePlayer == null || mc.thePlayer.inventory == null) return false;
        ItemStack held = mc.thePlayer.getHeldItem();
        if (isBlockStack(held)) return true;
        if (!ModConfig.autoSelectBlock) return false;

        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.thePlayer.inventory.getStackInSlot(i);
            if (isBlockStack(stack) && stack.stackSize > 0) {
                mc.thePlayer.inventory.currentItem = i;
                return true;
            }
        }
        return false;
    }

    private boolean isBlockStack(ItemStack stack) {
        return stack != null && stack.stackSize > 0 && stack.getItem() instanceof ItemBlock;
    }

    private boolean isAir(BlockPos pos) {
        return pos != null && mc.theWorld.getBlockState(pos) != null
                && mc.theWorld.getBlockState(pos).getBlock() == Blocks.air;
    }

    private void evaluateBuildingTarget() {
        EntityPlayerSP player = mc.thePlayer;
        if (player == null || mc.theWorld == null) {
            clearTarget();
            return;
        }

        double x = player.posX;
        double y = player.posY;
        double z = player.posZ;
        BlockPos underPlayer = new BlockPos(x, y - 1.0D, z);

        if (ModConfig.staircaseMode && !player.onGround && player.motionY > 0.0D) {
            underPlayer = new BlockPos(x, y, z);
        }

        if (!isAir(underPlayer)) {
            currentState = BuildState.TARGETING;
            targetPos = null;
            targetFacing = null;
            hitVector = null;
            return;
        }

        for (EnumFacing direction : HORIZONTAL_SEARCH) {
            BlockPos adjacent = underPlayer.offset(direction);
            if (!isAir(adjacent) && mc.theWorld.getBlockState(adjacent).getBlock()
                    .getMaterial().isSolid()) {
                setTarget(adjacent, direction.getOpposite());
                currentState = BuildState.PLACING;
                return;
            }
        }

        BlockPos below = underPlayer.down();
        if (!isAir(below) && mc.theWorld.getBlockState(below).getBlock().getMaterial().isSolid()) {
            setTarget(below, EnumFacing.UP);
            currentState = BuildState.PLACING;
            return;
        }

        clearTarget();
    }

    private void setTarget(BlockPos block, EnumFacing face) {
        targetPos = block;
        targetFacing = face;
        targetFacing = face;
        hitVector = new Vec3(
                block.getX() + 0.5D + face.getFrontOffsetX() * 0.5D,
                block.getY() + 0.5D + face.getFrontOffsetY() * 0.5D,
                block.getZ() + 0.5D + face.getFrontOffsetZ() * 0.5D
        );
    }

    private void executePlacement() {
        if (mc.thePlayer == null || mc.theWorld == null || mc.playerController == null
                || targetPos == null || targetFacing == null || hitVector == null) {
            clearTarget();
            return;
        }

        ItemStack held = mc.thePlayer.getHeldItem();
        if (!isBlockStack(held)) {
            currentState = BuildState.IDLE;
            return;
        }

        resetRightClickDelay();
        try {
            boolean success = mc.playerController.onPlayerRightClick(
                    mc.thePlayer, mc.theWorld, held, targetPos, targetFacing, hitVector);
            if (success) {
                mc.thePlayer.swingItem();
                currentState = BuildState.WAITING_NEXT_TICK;
            } else {
                currentState = BuildState.IDLE;
            }
        } catch (RuntimeException ignored) {
            // A failed placement attempt must not crash the client.
            currentState = BuildState.IDLE;
        }
    }

    public BuildState getCurrentState() {
        return currentState;
    }

    public BlockPos getTargetPos() {
        return targetPos;
    }
}
