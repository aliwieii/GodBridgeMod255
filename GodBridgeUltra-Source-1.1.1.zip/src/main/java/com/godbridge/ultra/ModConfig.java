package com.godbridge.ultra;

import net.minecraft.client.Minecraft;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public final class ModConfig {
    public static boolean enabled = false;
    public static boolean staircaseMode = true;
    public static boolean autoSelectBlock = true;
    public static boolean showHud = true;

    private static File getConfigFile() {
        File gameDir = Minecraft.getMinecraft() != null
                ? Minecraft.getMinecraft().mcDataDir : new File(".");
        return new File(new File(gameDir, "config"), "godbridgeultra.cfg");
    }

    private ModConfig() {}

    public static void loadConfig() {
        File configFile = getConfigFile();
        if (!configFile.isFile()) {
            saveConfig();
            return;
        }
        Properties props = new Properties();
        try (InputStream in = new FileInputStream(configFile)) {
            props.load(in);
            enabled = Boolean.parseBoolean(props.getProperty("enabled", "false"));
            staircaseMode = Boolean.parseBoolean(props.getProperty("staircaseMode", "true"));
            autoSelectBlock = Boolean.parseBoolean(props.getProperty("autoSelectBlock", "true"));
            showHud = Boolean.parseBoolean(props.getProperty("showHud", "true"));
        } catch (IOException ignored) {
            // Keep safe defaults if the configuration cannot be read.
        } catch (RuntimeException ignored) {
            // Malformed or inaccessible config must not prevent the game from starting.
        }
    }

    public static void saveConfig() {
        File configFile = getConfigFile();
        Properties props = new Properties();
        props.setProperty("enabled", String.valueOf(enabled));
        props.setProperty("staircaseMode", String.valueOf(staircaseMode));
        props.setProperty("autoSelectBlock", String.valueOf(autoSelectBlock));
        props.setProperty("showHud", String.valueOf(showHud));

        File parent = configFile.getParentFile();
        try {
            if (parent != null && !parent.isDirectory() && !parent.mkdirs() && !parent.isDirectory()) {
                return;
            }
            try (OutputStream out = new FileOutputStream(configFile)) {
                props.store(out, "GodBridgeUltra Configuration");
            }
        } catch (IOException ignored) {
            // Config persistence is best-effort; it must never crash the game.
        } catch (RuntimeException ignored) {
            // Ignore filesystem/runtime failures on Android launchers.
        }
    }
}
