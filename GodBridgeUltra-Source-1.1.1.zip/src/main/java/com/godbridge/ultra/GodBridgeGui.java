package com.godbridge.ultra;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;

public class GodBridgeGui extends GuiScreen {
    private GuiButton toggleBtn;
    private GuiButton staircaseBtn;
    private GuiButton autoSelectBtn;
    private GuiButton hudBtn;

    @Override
    public void initGui() {
        buttonList.clear();
        int centerX = width / 2;
        int startY = height / 4;

        toggleBtn = new GuiButton(1, centerX - 100, startY, "GodBridge: " + status(ModConfig.enabled));
        staircaseBtn = new GuiButton(2, centerX - 100, startY + 26, "Staircase Mode: " + status(ModConfig.staircaseMode));
        autoSelectBtn = new GuiButton(3, centerX - 100, startY + 52, "Auto Pick Blocks: " + status(ModConfig.autoSelectBlock));
        hudBtn = new GuiButton(4, centerX - 100, startY + 78, "Show HUD: " + status(ModConfig.showHud));

        buttonList.add(toggleBtn);
        buttonList.add(staircaseBtn);
        buttonList.add(autoSelectBtn);
        buttonList.add(hudBtn);
        buttonList.add(new GuiButton(200, centerX - 100, startY + 114, "Done"));
    }

    private String status(boolean value) {
        return value ? "ON" : "OFF";
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button == null) return;
        switch (button.id) {
            case 1:
                ModConfig.enabled = !ModConfig.enabled;
                button.displayString = "GodBridge: " + status(ModConfig.enabled);
                break;
            case 2:
                ModConfig.staircaseMode = !ModConfig.staircaseMode;
                button.displayString = "Staircase Mode: " + status(ModConfig.staircaseMode);
                break;
            case 3:
                ModConfig.autoSelectBlock = !ModConfig.autoSelectBlock;
                button.displayString = "Auto Pick Blocks: " + status(ModConfig.autoSelectBlock);
                break;
            case 4:
                ModConfig.showHud = !ModConfig.showHud;
                button.displayString = "Show HUD: " + status(ModConfig.showHud);
                break;
            case 200:
                ModConfig.saveConfig();
                if (mc != null) mc.displayGuiScreen(null);
                break;
            default:
                break;
        }
    }

    @Override
    public void onGuiClosed() {
        ModConfig.saveConfig();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        drawCenteredString(fontRendererObj, "GodBridgeUltra Settings", width / 2, 20, 0xFFFFFF);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
}
